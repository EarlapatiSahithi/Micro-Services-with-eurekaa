package com.get.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
