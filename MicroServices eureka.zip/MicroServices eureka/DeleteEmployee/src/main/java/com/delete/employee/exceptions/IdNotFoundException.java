package com.delete.employee.exceptions;

public class IdNotFoundException extends Exception {
	public IdNotFoundException(String errorMsg){
		super(errorMsg);
	}

}