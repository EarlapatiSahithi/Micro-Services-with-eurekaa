package com.createemployee.Service;

import com.createemployee.entities.Employee;

public interface EmployeeCreateServiceI {
 Employee CreateEmployee(Employee employee);
}
