package com.fetch.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableEurekaClient
public class FetchEmployeeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FetchEmployeeServiceApplication.class, args);
	}

}
