package com.fetch.employee.service;

import java.util.List;

import com.fetch.employee.entity.Employee;

public interface EmployeeServiceI {

	List<Employee> fetchAllEmployees();

}
