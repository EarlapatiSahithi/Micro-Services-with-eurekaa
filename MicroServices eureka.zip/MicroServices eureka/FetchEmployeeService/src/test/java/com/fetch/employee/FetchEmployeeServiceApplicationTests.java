package com.fetch.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FetchEmployeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
