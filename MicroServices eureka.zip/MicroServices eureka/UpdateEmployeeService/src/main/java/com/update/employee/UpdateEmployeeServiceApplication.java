package com.update.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableEurekaClient
public class UpdateEmployeeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpdateEmployeeServiceApplication.class, args);
	}

}
