package com.update.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpdateEmployeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
